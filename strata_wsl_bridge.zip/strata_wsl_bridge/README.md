# Windows 10 Strata → WSL2 Ubuntu

這份範例讓 Windows 執行 Strata、存放模型，WSL2 Ubuntu 只透過 HTTP API 提問。預設使用 `C:\Strata-main`、`strata-nvfp4-nvfp4.json` 和埠號 `8081`，不會在 Ubuntu 安裝第二份模型。請先確認設定檔中的模型路徑已指向實際存在的 `C:\Strata-Data` 檔案。

Strata 的 OpenAI 相容網址在 WSL2 是 `http://<Windows 在 WSL2 的閘道 IP>:8081/v1`。Windows 10 的 WSL2 通常使用 NAT；閘道和 WSL2 位址可能在重啟後改變。不要把 `0.0.0.0` 填進客戶端網址，它只用於服務監聽。

## 第一次設定

把整個資料夾放在 Windows，例如 `C:\Users\kevin\Downloads\strata_wsl_bridge`。先關閉正在運行的 Strata。在一般 PowerShell 視窗中：

```powershell
cd 'C:\Users\kevin\Downloads\strata_wsl_bridge'
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\windows-strata.ps1 -Action configure
```

`configure` 會先將設定檔裡的 `D:\Strata-data` 路徑改成 `C:\Strata-Data`，確認對應的模型檔案存在，再備份及儲存設定檔。它也會設定 `host` 為 `0.0.0.0`、設定埠號 8081，並在尚未設定 API key 時產生隨機 key。key 只存放在 Windows 的 Strata 設定檔；腳本不會顯示它，也不會改動模型資料。如果模型尚未複製完整，會先停止並指出缺少哪個檔案。已存在的 API key 會保留。

在**系統管理員 PowerShell** 中，使用你的實際 WSL 發行版名稱設定防火牆，例如 `Ubuntu-24.04`：

```powershell
cd 'C:\Users\kevin\Downloads\strata_wsl_bridge'
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\windows-strata.ps1 -Action firewall -Distro Ubuntu-24.04
```

防火牆規則僅允許目前 WSL2 的來源 IP，連到 Windows 的 WSL2 閘道 IP、TCP 8081。它不限制 Python 執行檔路徑，因為 Strata 可能使用虛擬環境或系統 Python；API key 仍是必要條件。WSL2 網路位址若在重啟後改變，要重新執行 `firewall`。請檢查並移除自己先前為 Python 或 8081 建立的寬鬆防火牆允許規則，否則它們仍可能另外允許其他裝置連線。

若 Windows 本機可以連上 Strata，但 WSL2 的 TCP 連線仍逾時，檢查 Windows 是否已有針對實際 Python 執行檔的入站封鎖規則。Windows 防火牆的封鎖規則優先於這份工具新增的允許規則。在系統管理員 PowerShell 中，先用 `Get-NetTCPConnection -State Listen -LocalPort 8081` 找出服務的程序 ID，再用 `Get-Process -Id <程序 ID> | Select-Object Path` 確認執行檔。若確認同一執行檔有 `-Action Block` 的有效規則，可用 `Disable-NetFirewallRule -Name '<規則名稱>'` 暫時停用該規則並重試 WSL 連線；若仍失敗，使用 `Enable-NetFirewallRule -Name '<規則名稱>'` 還原。停用封鎖規則後，其他既有的允許規則仍可能生效，請核對其適用範圍。

回到**一般 PowerShell** 視窗啟動服務：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\windows-strata.ps1 -Action serve
```

保留這個視窗開啟。`Ctrl+C` 停止服務。若埠號已被占用，先停止舊的 Strata 實例；腳本不會結束其他程序。模型首次載入可能很慢，以另一個 PowerShell 視窗的檢查為準：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\windows-strata.ps1 -Action check
```

要使用別的安裝位置、設定檔、資料路徑、埠號或 WSL 發行版，可將 `-Root 'C:\...' -ConfigName 'strata-....json' -OldDataDir 'D:\...' -DataDir 'C:\...' -Port 8081 -Distro 'Ubuntu'` 同時傳給相關指令。

## 從 WSL2 Ubuntu 連線

在 Ubuntu 中，先確認有 `python3` 與 `ip` 指令。從 ZIP 解壓的 Windows 資料夾執行：

```bash
cd /mnt/c/Users/kevin/Downloads/strata_wsl_bridge
python3 check-strata.py --config /mnt/c/Strata-main/strata-nvfp4-nvfp4.json
```

檢查器會重新取得閘道 IP，呼叫 `/health` 和需認證的 `/v1/models`。要再做一次真正的模型提問：

```bash
python3 check-strata.py --config /mnt/c/Strata-main/strata-nvfp4-nvfp4.json --infer --timeout 900
```

檢查成功後，它會在 Ubuntu 的家目錄寫入權限為 `0600` 的 `~/strata-wsl.env`，其中有 API 網址與 API key，供 WSL2 內的程式使用。不要分享這個檔案或把 key 貼到聊天中。每次重新開啟 Ubuntu 終端機，可執行：

```bash
source ~/strata-wsl.env
printf '%s\n' "$OPENAI_BASE_URL" "$STRATA_MODEL"
```

如需即時重新取得可能改變的閘道 IP，重跑 `check-strata.py`，再 `source` 新產生的檔案。若防火牆規則中的 WSL2 位址已變，也要在 Windows 重新執行 `firewall`。

Python 使用 OpenAI 套件的例子：

```python
import os
from openai import OpenAI

client = OpenAI(base_url=os.environ["OPENAI_BASE_URL"], api_key=os.environ["OPENAI_API_KEY"])
response = client.chat.completions.create(
    model=os.environ["STRATA_MODEL"],
    messages=[{"role": "user", "content": "請用繁體中文打個招呼。"}],
    max_tokens=128,
)
print(response.choices[0].message.content)
```

先在 Ubuntu 的 Python 虛擬環境安裝 `openai` 套件；檢查器本身只用 Python 標準函式庫。

## 還原

關閉服務後，在一般 PowerShell 執行 `-Action restore`，可將這份工具首次設定前的 `host`、`port` 和 `api_key` 還原。以系統管理員 PowerShell 執行同一動作，可另外刪除這份工具建立的防火牆規則。模型資料與已修正為 C: 的檔案路徑會保留；首次設定時的完整設定檔備份也保留在程式資料夾中。若已產生 `~/strata-wsl.env`，停用這條連線後可自行刪除該檔。

這份工具尚未在你的 Windows 10／WSL2 電腦執行。是否真的連通，必須以你的 Windows `check` 和 WSL2 `--infer` 結果確認。
