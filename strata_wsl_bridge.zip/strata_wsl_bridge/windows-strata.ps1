# Windows PowerShell 5.1. Configure the existing Strata installation for WSL2 NAT clients.
[CmdletBinding()]
param(
    [ValidateSet('configure','firewall','serve','check','restore')]
    [string]$Action = 'check',
    [string]$Root = 'C:\Strata-main',
    [string]$ConfigName = 'strata-nvfp4-nvfp4.json',
    [string]$OldDataDir = 'D:\Strata-data',
    [string]$DataDir = 'C:\Strata-Data',
    [ValidateRange(1,65535)][int]$Port = 8081,
    [string]$Distro = 'Ubuntu-24.04'
)
$ErrorActionPreference = 'Stop'
$configPath = Join-Path $Root $ConfigName
$pythonPath = Join-Path $Root '.venv\Scripts\python.exe'
$serverPath = Join-Path $Root 'serve\server.py'
$ruleName = "Strata-WSL-Bridge-$Port"
$backupPath = "$configPath.wsl-bridge-original.bak"

function Require-Admin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Open PowerShell as Administrator to change Windows Firewall.'
    }
}
function Read-Config {
    if (-not (Test-Path -LiteralPath $configPath -PathType Leaf)) {
        throw "Strata config missing: $configPath"
    }
    return (Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json)
}
function Save-Config($cfg) {
    $json = $cfg | ConvertTo-Json -Depth 100
    $utf8 = [System.Text.UTF8Encoding]::new($false)
    [System.IO.File]::WriteAllText($configPath, $json + [Environment]::NewLine, $utf8)
}
function Set-Field($cfg, [string]$name, $value) {
    if ($cfg.PSObject.Properties[$name]) { $cfg.$name = $value }
    else { $cfg | Add-Member -NotePropertyName $name -NotePropertyValue $value }
}
function Check-Model-Paths($cfg) {
    $paths = @($cfg.exe) + @($cfg.args | Where-Object { $_ -is [string] -and $_.EndsWith('.gguf') })
    foreach ($path in $paths) {
        if ($path -and -not (Test-Path -LiteralPath $path)) {
            throw "Model or engine file missing: $path. Repair the path in $configPath before configuring the bridge."
        }
    }
}
function Get-Network {
    $route = (& wsl.exe -d $Distro -- ip -4 route show default 2>&1 | Out-String).Trim()
    if ($LASTEXITCODE -ne 0 -or $route -notmatch '\bvia\s+([0-9.]+)') {
        throw "Cannot read WSL2 gateway. Check wsl.exe --list --verbose and the -Distro parameter."
    }
    $gateway = $Matches[1]
    $reply = (& wsl.exe -d $Distro -- ip -4 route get $gateway 2>&1 | Out-String).Trim()
    if ($LASTEXITCODE -ne 0 -or $reply -notmatch '\bsrc\s+([0-9.]+)') {
        throw 'Cannot determine WSL2 source IPv4 address.'
    }
    $source = $Matches[1]
    if (-not (Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
            Where-Object { $_.IPAddress -eq $gateway })) {
        throw "WSL2 gateway $gateway is not a Windows IPv4 address. Check VPN and routing."
    }
    return @{ Gateway = $gateway; Source = $source }
}

switch ($Action) {
    'configure' {
        $raw = [System.IO.File]::ReadAllText($configPath)
        # JSON escapes a Windows backslash as two backslashes.
        $oldJsonPath = $OldDataDir.Replace('\', '\\')
        $newJsonPath = $DataDir.Replace('\', '\\')
        $updated = $raw.Replace($oldJsonPath, $newJsonPath)
        $cfg = $updated | ConvertFrom-Json
        Check-Model-Paths $cfg
        if (-not (Test-Path -LiteralPath $pythonPath -PathType Leaf)) { throw "Strata Python missing: $pythonPath" }
        if (-not (Test-Path -LiteralPath $backupPath)) {
            Copy-Item -LiteralPath $configPath -Destination $backupPath -ErrorAction Stop
        }
        $key = $cfg.api_key
        if (-not $key -or ($key -is [string] -and -not $key.Trim())) {
            $bytes = New-Object byte[] 32
            $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
            try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
            $key = [Convert]::ToBase64String($bytes).TrimEnd('=').Replace('+','-').Replace('/','_')
            Set-Field $cfg 'api_key' $key
            Write-Host 'Generated an API key in the Strata config. Its value is not displayed.'
        } else {
            Write-Host 'Preserved the existing Strata API key.'
        }
        Set-Field $cfg 'host' '0.0.0.0'
        Set-Field $cfg 'port' $Port
        Save-Config $cfg
        Write-Host "Saved $configPath (data paths at $DataDir, host 0.0.0.0, port $Port). Original: $backupPath"
        Write-Host 'Run firewall as Administrator; then run serve in ordinary PowerShell.'
    }
    'firewall' {
        Require-Admin
        $network = Get-Network
        $existing = Get-NetFirewallRule -Name $ruleName -ErrorAction SilentlyContinue
        if ($existing) { $existing | Remove-NetFirewallRule }
        New-NetFirewallRule -Name $ruleName -DisplayName "Strata from WSL2 only ($Port)" `
            -Direction Inbound -Action Allow -Protocol TCP -LocalPort $Port `
            -LocalAddress $network.Gateway -RemoteAddress $network.Source `
            -Profile Any | Out-Null
        Write-Host "Allowed WSL2 $($network.Source) -> Windows $($network.Gateway):$Port"
    }
    'serve' {
        $cfg = Read-Config
        Check-Model-Paths $cfg
        if (-not $cfg.api_key) { throw 'Configure an API key before accepting WSL2 connections.' }
        if (-not (Test-Path -LiteralPath $pythonPath -PathType Leaf)) { throw "Strata Python missing: $pythonPath" }
        if (-not (Test-Path -LiteralPath $serverPath -PathType Leaf)) { throw "Strata server missing: $serverPath" }
        if (Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue) {
            throw "TCP $Port is already in use. Stop the existing Strata server before starting this one."
        }
        $previousKey = $env:STRATA_API_KEY
        try {
            $env:STRATA_API_KEY = '' # use the key saved in this model's config
            Write-Host "Starting Windows Strata on 0.0.0.0:$Port. Keep this window open."
            & $pythonPath $serverPath --engine strata --config $configPath --host 0.0.0.0 --port $Port
            if ($LASTEXITCODE -ne 0) { throw "Strata server exited with code $LASTEXITCODE" }
        } finally { $env:STRATA_API_KEY = $previousKey }
    }
    'check' {
        $cfg = Read-Config
        Write-Host "Config: $configPath; host: $($cfg.host); port: $Port; API key configured: $([bool]$cfg.api_key)"
        Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue |
            Select-Object LocalAddress,LocalPort,OwningProcess | Format-Table
        try {
            $health = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/health" -TimeoutSec 10
            Write-Host "Health: $($health.status); loaded: $($health.loaded); model: $($health.model)"
        } catch { Write-Warning "Windows local health request failed: $($_.Exception.Message)" }
        Get-NetFirewallRule -Name $ruleName -ErrorAction SilentlyContinue |
            Select-Object Name,Enabled,Direction,Action | Format-Table
    }
    'restore' {
        if (-not (Test-Path -LiteralPath $backupPath -PathType Leaf)) { throw "No original config backup: $backupPath" }
        $original = Get-Content -LiteralPath $backupPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $current = Read-Config
        foreach ($name in @('host','port','api_key')) {
            if ($original.PSObject.Properties[$name]) { Set-Field $current $name $original.$name }
            elseif ($current.PSObject.Properties[$name]) { $current.PSObject.Properties.Remove($name) }
        }
        Save-Config $current
        Write-Host "Restored the original host, port and API key fields from $backupPath; data paths remain as they are."
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($identity)
        if ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
            Get-NetFirewallRule -Name $ruleName -ErrorAction SilentlyContinue | Remove-NetFirewallRule
            Write-Host "Removed firewall rule $ruleName"
        } else { Write-Host "To remove firewall rule $ruleName, rerun restore as Administrator." }
    }
}
