# Windows PowerShell 5.1. One command for an existing Strata install and WSL2.
[CmdletBinding()]
param(
    [string]$Root = 'C:\Strata-main',
    [string]$DataDir = 'C:\Strata-Data',
    [string]$ConfigName = 'strata-nvfp4-nvfp4.json',
    [string]$Distro = 'MEL-ubuntu',
    [ValidateRange(1, 65535)][int]$Port = 8081,
    [switch]$SkipInference
)

$ErrorActionPreference = 'Stop'
$configPath = Join-Path $Root $ConfigName
$pythonPath = Join-Path $Root '.venv\Scripts\python.exe'
$serverPath = Join-Path $Root 'serve\server.py'
$helperPath = Join-Path $PSScriptRoot 'FIREWALL.ps1'
$checkerPath = Join-Path $PSScriptRoot 'check-strata.py'
$stdoutPath = Join-Path $PSScriptRoot 'strata-server.out.log'
$stderrPath = Join-Path $PSScriptRoot 'strata-server.err.log'
$firewallResultPath = Join-Path $PSScriptRoot 'firewall-result.txt'
$firewallErrorPath = Join-Path $PSScriptRoot 'firewall-error.txt'

function Set-Field($cfg, [string]$name, $value) {
    if ($cfg.PSObject.Properties[$name]) { $cfg.$name = $value }
    else { $cfg | Add-Member -NotePropertyName $name -NotePropertyValue $value }
}

function Get-WslNetwork {
    $routeOutput = & wsl.exe -d $Distro -- ip -4 route show default 2>&1
    if ($LASTEXITCODE -ne 0) { throw "Cannot read the $Distro WSL2 route: $routeOutput" }
    $route = ($routeOutput | Out-String).Trim()
    if ($route -notmatch '\bvia\s+([0-9.]+)') { throw "No WSL2 gateway in: $route" }
    $gateway = $Matches[1]
    $replyOutput = & wsl.exe -d $Distro -- ip -4 route get $gateway 2>&1
    if ($LASTEXITCODE -ne 0) { throw "Cannot read the $Distro source address: $replyOutput" }
    $reply = ($replyOutput | Out-String).Trim()
    if ($reply -notmatch '\bsrc\s+([0-9.]+)') { throw "No WSL2 source IP in: $reply" }
    $source = $Matches[1]
    [void][System.Net.IPAddress]::Parse($gateway)
    [void][System.Net.IPAddress]::Parse($source)
    return @{ Gateway = $gateway; Source = $source }
}

function Update-Config {
    if (-not (Test-Path -LiteralPath $configPath -PathType Leaf)) { throw "Missing Strata config: $configPath" }
    $raw = [System.IO.File]::ReadAllText($configPath)
    $oldJsonPath = 'D:\Strata-data'.Replace('\', '\\')
    $newJsonPath = $DataDir.Replace('\', '\\')
    $updated = $raw.Replace($oldJsonPath, $newJsonPath)
    $cfg = $updated | ConvertFrom-Json
    $paths = @($cfg.exe) + @($cfg.args | Where-Object { $_ -is [string] -and $_.EndsWith('.gguf') })
    foreach ($path in $paths) {
        if ($path -and -not (Test-Path -LiteralPath $path -PathType Leaf)) {
            throw "Missing engine or model file: $path. No model download will be started."
        }
    }
    $changed = $updated -cne $raw
    $key = $cfg.api_key
    if (-not $key -or ($key -is [string] -and -not $key.Trim())) {
        $bytes = New-Object byte[] 32
        $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
        try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
        $key = [Convert]::ToBase64String($bytes).TrimEnd('=').Replace('+','-').Replace('/','_')
        Set-Field $cfg 'api_key' $key
        $changed = $true
        Write-Host 'Created a random Strata API key in the config; it will not be printed.'
    }
    if ($cfg.host -ne '0.0.0.0') { Set-Field $cfg 'host' '0.0.0.0'; $changed = $true }
    if ("$($cfg.port)" -ne "$Port") { Set-Field $cfg 'port' $Port; $changed = $true }
    if ($changed) {
        if (Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue) {
            throw "Strata config needs updating while port $Port is in use. Close the current Strata window and run this installer again."
        }
        $backupPath = "$configPath.oneclick-original.bak"
        if (-not (Test-Path -LiteralPath $backupPath)) {
            Copy-Item -LiteralPath $configPath -Destination $backupPath -ErrorAction Stop
        }
        $utf8 = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($configPath, ($cfg | ConvertTo-Json -Depth 100) + [Environment]::NewLine, $utf8)
        Write-Host "Updated config: $configPath (original backup: $backupPath)"
    } else {
        Write-Host 'Existing Strata config is ready; no rewrite needed.'
    }
}

function Wait-For-Strata {
    $deadline = (Get-Date).AddMinutes(20)
    $lastNotice = (Get-Date).AddSeconds(-31)
    while ((Get-Date) -lt $deadline) {
        try {
            $health = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/health" -TimeoutSec 5
            if ($health.service -ne 'strata') { throw "Port $Port serves a different application." }
            if ($health.status -eq 'ok' -and $health.loaded) { return $health }
        } catch {
            if ($_.Exception.Message -like '*different application*') { throw }
        }
        if ((Get-Date) -gt $lastNotice.AddSeconds(30)) {
            Write-Host 'Waiting for Strata to load; first start can take many minutes...'
            $lastNotice = Get-Date
        }
        Start-Sleep -Seconds 5
    }
    throw "Strata did not become ready in 20 minutes. Read $stderrPath and $stdoutPath."
}

try {
    if ($PSScriptRoot -match '"') { throw 'The ZIP extraction path cannot contain a double quote.' }
    foreach ($path in @($pythonPath, $serverPath, $helperPath, $checkerPath)) {
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Missing required file: $path" }
    }
    Write-Host "Using existing Strata: $Root"
    Write-Host "Model data: $DataDir; WSL distribution: $Distro; port: $Port"
    $network = Get-WslNetwork
    Write-Host "WSL2 $($network.Source) -> Windows $($network.Gateway):$Port"
    Update-Config

    $listeners = @(Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue)
    if (-not $listeners.Count) {
        $arguments = '"{0}" --engine strata --config "{1}" --host 0.0.0.0 --port {2}' -f $serverPath, $configPath, $Port
        $oldKey = $env:STRATA_API_KEY
        try {
            $env:STRATA_API_KEY = ''
            Start-Process -FilePath $pythonPath -ArgumentList $arguments -WorkingDirectory $Root -RedirectStandardOutput $stdoutPath -RedirectStandardError $stderrPath | Out-Null
        } finally {
            $env:STRATA_API_KEY = $oldKey
        }
        Write-Host "Started Strata; logs: $stdoutPath and $stderrPath"
    } elseif (-not ($listeners | Where-Object { $_.LocalAddress -eq '0.0.0.0' -or $_.LocalAddress -eq $network.Gateway })) {
        throw "Port $Port is listening only on localhost. Close that Strata window and run this installer again."
    } else {
        Write-Host "Using the Strata process already listening on port $Port."
    }
    $health = Wait-For-Strata
    Write-Host "Windows health passed: $($health.model)"

    Remove-Item -LiteralPath $firewallResultPath, $firewallErrorPath -ErrorAction SilentlyContinue
    $adminArgs = '-NoProfile -ExecutionPolicy Bypass -File "{0}" -Mode install -Gateway {1} -Source {2} -Port {3}' -f $helperPath, $network.Gateway, $network.Source, $Port
    Write-Host 'Windows will request administrator permission to configure the scoped firewall rule.'
    $admin = Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $adminArgs -PassThru -Wait
    if ($admin.ExitCode -ne 0) {
        $reason = if (Test-Path -LiteralPath $firewallErrorPath) { Get-Content -LiteralPath $firewallErrorPath -Raw } else { "exit code $($admin.ExitCode)" }
        throw "Firewall setup failed: $reason"
    }
    if (Test-Path -LiteralPath $firewallResultPath) {
        Get-Content -LiteralPath $firewallResultPath | ForEach-Object { Write-Host $_ }
    }

    $linuxChecker = ((& wsl.exe -d $Distro -- wslpath -u $checkerPath) | Out-String).Trim()
    if ($LASTEXITCODE -ne 0 -or -not $linuxChecker) { throw "Cannot map checker path into $Distro WSL2." }
    $linuxConfig = ((& wsl.exe -d $Distro -- wslpath -u $configPath) | Out-String).Trim()
    if ($LASTEXITCODE -ne 0 -or -not $linuxConfig) { throw "Cannot map config path into $Distro WSL2." }
    $checkArgs = @('-d', $Distro, '--', 'python3', $linuxChecker, '--config', $linuxConfig, '--port', "$Port")
    if (-not $SkipInference) { $checkArgs += @('--infer', '--timeout', '900') }
    Write-Host 'Checking the OpenAI-compatible API from inside WSL2...'
    & wsl.exe @checkArgs
    if ($LASTEXITCODE -ne 0) { throw "WSL2 API check failed with exit code $LASTEXITCODE." }
    Write-Host 'DONE: Windows Strata is reachable from WSL2. No model files were copied.'
} catch {
    Write-Host "FAILED: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
