@echo off
cd /d "%~dp0"
if not exist "%~dp0INSTALL.ps1" (
    echo Please extract the complete ZIP before running this file.
    pause
    exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALL.ps1"
set "install_result=%ERRORLEVEL%"
echo.
if not "%install_result%"=="0" echo Setup stopped. Read the FAILED message above.
pause
exit /b %install_result%
