# Run by INSTALL.ps1 through Windows UAC. Only the two observed Python blocks may be disabled.
[CmdletBinding()]
param(
    [ValidateSet('install', 'restore')][string]$Mode = 'install',
    [string]$Gateway,
    [string]$Source,
    [ValidateRange(1, 65535)][int]$Port = 8081
)

$ErrorActionPreference = 'Stop'
$ruleName = "Strata-WSL-Bridge-$Port"
$statePath = Join-Path $PSScriptRoot 'bridge-state.json'
$resultPath = Join-Path $PSScriptRoot 'firewall-result.txt'
$errorPath = Join-Path $PSScriptRoot 'firewall-error.txt'
$knownPythonBlocks = @(
    '{3B3AFB56-6CED-4304-BDCA-FCE5021C313D}',
    '{16CF1CAB-93F4-48C0-9A8F-74D274EDB427}'
)

function Write-Result([string[]]$lines) {
    $utf8 = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllLines($resultPath, $lines, $utf8)
}

function Test-PortIncludes([object]$ports, [int]$target) {
    foreach ($item in @($ports)) {
        foreach ($part in ("$item" -split ',')) {
            $part = $part.Trim()
            if ($part -eq 'Any' -or $part -eq "$target") { return $true }
            if ($part -match '^(\d+)-(\d+)$' -and
                $target -ge [int]$Matches[1] -and $target -le [int]$Matches[2]) { return $true }
        }
    }
    return $false
}

function Get-OtherPublicAllows([string]$exe, [string]$gateway, [string]$source, [int]$port) {
    $findings = @()
    $rules = Get-NetFirewallRule -PolicyStore ActiveStore -Direction Inbound -Action Allow -Enabled True
    foreach ($rule in $rules) {
        if ($rule.Name -eq $ruleName -or "$($rule.Profile)" -notmatch 'Public|Any') { continue }
        $app = $rule | Get-NetFirewallApplicationFilter
        $ports = $rule | Get-NetFirewallPortFilter
        $program = "$($app.Program)"
        $protocol = "$($ports.Protocol)"
        $isPythonRule = $program -ieq $exe
        $isPortRule = $program -eq 'Any' -and $protocol -match '^(TCP|Any|6)$' -and
            (Test-PortIncludes $ports.LocalPort $port) -and
            "$((($rule | Get-NetFirewallServiceFilter).Service))" -eq 'Any'
        if (-not ($isPythonRule -or $isPortRule)) { continue }
        $addresses = $rule | Get-NetFirewallAddressFilter
        $local = @($addresses.LocalAddress)
        $remote = @($addresses.RemoteAddress)
        if ($local.Count -eq 1 -and $local[0] -eq $gateway -and
            $remote.Count -eq 1 -and $remote[0] -eq $source) { continue }
        $findings += "Name=$($rule.Name); Program=$program; Port=$($ports.LocalPort); Local=$($local -join ','); Remote=$($remote -join ',')"
    }
    return $findings
}

try {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Windows administrator permission was not granted.'
    }
    Remove-Item -LiteralPath $errorPath -ErrorAction SilentlyContinue

    if ($Mode -eq 'restore') {
        $bridgeRule = Get-NetFirewallRule -Name $ruleName -ErrorAction SilentlyContinue
        if ($bridgeRule) { $bridgeRule | Remove-NetFirewallRule }
        $restored = @()
        if (Test-Path -LiteralPath $statePath -PathType Leaf) {
            $state = Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($name in @($state.DisabledRuleNames)) {
                if ($name) {
                    $rule = Get-NetFirewallRule -Name $name -ErrorAction SilentlyContinue
                    if ($rule) {
                        Enable-NetFirewallRule -Name $name
                        $restored += $name
                    }
                }
            }
            Remove-Item -LiteralPath $statePath
        }
        Write-Result @("Removed $ruleName", "Re-enabled rules disabled by this installer: $($restored -join ', ')")
        exit 0
    }

    if (-not $Gateway -or -not $Source) { throw 'Gateway and Source are required for install.' }
    foreach ($address in @($Gateway, $Source)) {
        $parsed = [System.Net.IPAddress]::Parse($address)
        if ($parsed.AddressFamily -ne [System.Net.Sockets.AddressFamily]::InterNetwork) {
            throw "Expected an IPv4 address: $address"
        }
    }
    if (-not (Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -eq $Gateway })) {
        throw "The WSL2 gateway $Gateway is not assigned to Windows."
    }
    $listener = Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction Stop |
        Where-Object { $_.LocalAddress -eq '0.0.0.0' -or $_.LocalAddress -eq $Gateway } |
        Select-Object -First 1
    if (-not $listener) { throw "No Strata process is listening for WSL2 on port $Port." }
    $serverExe = (Get-Process -Id $listener.OwningProcess -ErrorAction Stop).Path
    if (-not $serverExe) {
        $serverExe = (Get-CimInstance Win32_Process -Filter "ProcessId=$($listener.OwningProcess)").ExecutablePath
    }
    if (-not $serverExe) { throw 'Cannot identify the running Strata executable.' }

    $publicProfile = Get-NetFirewallProfile -PolicyStore ActiveStore -Name Public
    if ("$($publicProfile.Enabled)" -ne 'True' -or
        "$($publicProfile.DefaultInboundAction)" -ne 'Block') {
        throw 'Public firewall must be enabled with default inbound action Block.'
    }
    $otherAllows = @(Get-OtherPublicAllows $serverExe $Gateway $Source $Port)
    if ($otherAllows.Count) {
        throw "Other Public inbound allow rules may expose Python or port $($Port):`n$($otherAllows -join [Environment]::NewLine)`nReview and narrow or disable them, then rerun. No existing allow rule was changed."
    }

    $existing = Get-NetFirewallRule -Name $ruleName -ErrorAction SilentlyContinue
    if ($existing) { $existing | Remove-NetFirewallRule }
    New-NetFirewallRule -Name $ruleName -DisplayName "Strata from WSL2 only ($Port)" -Direction Inbound -Action Allow -Program $serverExe -Protocol TCP -LocalPort $Port -LocalAddress $Gateway -RemoteAddress $Source -Profile Any | Out-Null

    $state = @{ Version = 1; DisabledRuleNames = @() }
    if (Test-Path -LiteralPath $statePath -PathType Leaf) {
        $oldState = Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json
        $state.DisabledRuleNames = @($oldState.DisabledRuleNames | Where-Object { $_ })
    }
    $toDisable = @()
    foreach ($name in $knownPythonBlocks) {
        $block = Get-NetFirewallRule -PolicyStore ActiveStore -Name $name -ErrorAction SilentlyContinue
        if (-not $block -or $block.Enabled -ne 'True') { continue }
        $program = ($block | Get-NetFirewallApplicationFilter).Program
        if ($block.Direction -eq 'Inbound' -and $block.Action -eq 'Block' -and
            "$($block.Profile)" -eq 'Public' -and $program -ieq $serverExe) {
            if ($block.PolicyStoreSourceType -ne 'Local') {
                throw "Matching Python block $name is policy-managed; cannot disable it."
            }
            $toDisable += $name
        }
    }
    if ($toDisable.Count) {
        $newlyDisabled = @()
        try {
            foreach ($name in $toDisable) {
                Disable-NetFirewallRule -Name $name
                $newlyDisabled += $name
                $state.DisabledRuleNames = @($state.DisabledRuleNames + $name | Select-Object -Unique)
            }
            $utf8 = New-Object System.Text.UTF8Encoding($false)
            [System.IO.File]::WriteAllText($statePath, ($state | ConvertTo-Json -Depth 5), $utf8)
        } catch {
            foreach ($name in $newlyDisabled) { Enable-NetFirewallRule -Name $name }
            throw
        }
    }
    $active = Get-NetFirewallRule -PolicyStore ActiveStore -Name $ruleName -ErrorAction Stop
    if (-not $active -or $active.Enabled -ne 'True') { throw 'The WSL2 allow rule is not active.' }
    $activeProgram = ($active | Get-NetFirewallApplicationFilter).Program
    $activeAddress = $active | Get-NetFirewallAddressFilter
    if ($activeProgram -ine $serverExe -or
        @($activeAddress.LocalAddress).Count -ne 1 -or @($activeAddress.LocalAddress)[0] -ne $Gateway -or
        @($activeAddress.RemoteAddress).Count -ne 1 -or @($activeAddress.RemoteAddress)[0] -ne $Source) {
        throw 'The active WSL2 rule does not have the expected program and NAT addresses.'
    }
    $lines = @(
        "Allowed WSL2 $Source -> Windows $($Gateway):$Port.",
        "Allowed program: $serverExe; TCP port: $Port; Public default inbound: Block",
        'No other broad Public allow rule for this Python or port was detected.',
        "Python Public block rules disabled by this run: $($toDisable -join ', ')"
    )
    Write-Result $lines
    exit 0
} catch {
    $message = $_.Exception.Message
    $utf8 = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($errorPath, $message, $utf8)
    exit 1
}
