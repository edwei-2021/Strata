#!/usr/bin/env python3
"""Ask Windows Strata through its OpenAI-compatible API, without pip packages."""

import argparse
import json
import os
import sys
import urllib.error
import urllib.request


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("question", nargs="?", default="請用繁體中文打個招呼。")
    parser.add_argument("--timeout", type=float, default=900)
    args = parser.parse_args()
    base = os.environ.get("OPENAI_BASE_URL", "").rstrip("/")
    key = os.environ.get("OPENAI_API_KEY", "")
    model = os.environ.get("STRATA_MODEL", "")
    if not base or not key or not model:
        raise ValueError("First run: source ~/strata-wsl.env")
    if args.timeout <= 0:
        parser.error("--timeout must be positive")
    body = json.dumps({
        "model": model,
        "stream": False,
        "messages": [{"role": "user", "content": args.question}],
        "max_tokens": 256,
        "reasoning_effort": "none",
    }).encode("utf-8")
    request = urllib.request.Request(
        base + "/chat/completions",
        data=body,
        headers={
            "Authorization": "Bearer " + key,
            "Content-Type": "application/json",
        },
    )
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(request, timeout=args.timeout) as response:
        answer = json.load(response)
    print(answer["choices"][0]["message"]["content"])


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, IndexError, TypeError, urllib.error.URLError) as error:
        print("FAIL:", error, file=sys.stderr)
        sys.exit(1)
