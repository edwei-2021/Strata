# Strata Windows → WSL2：單次設定包

這個 ZIP 專為目前的環境準備：Windows 10 上已有 C:\Strata-main 和 C:\Strata-Data，WSL 發行版名稱為 MEL-ubuntu，Strata API 使用 8081。模型仍只放在 Windows；本工具不會重新執行 Strata setup，也不會下載或複製模型。

## 一次執行

把 ZIP **完整解壓縮**到 D:\agent-evolution-platform，確認出現 D:\agent-evolution-platform\strata_wsl_oneclick\RUN-ONCE.bat。在一般 Windows PowerShell 執行這一行，或直接雙擊該 BAT：

    & 'D:\agent-evolution-platform\strata_wsl_oneclick\RUN-ONCE.bat'

執行時 Windows 會跳出一次系統管理員權限視窗；請允許它設定防火牆。安裝程式會依序檢查現有模型與設定、在需要時啟動 Strata、設定僅供當前 WSL 位址使用的防火牆規則，然後從 WSL 實際呼叫 OpenAI 相容 API。模型第一次啟動可能需要十幾分鐘；BAT 視窗會持續顯示進度。看到 DONE 和 PASS inference 才表示完整成功。

可以在 WSL IP 改變後重新執行同一個 BAT。它會重用已在運行的 Strata，並更新防火牆允許的 WSL 位址。若 8081 上已有另一個服務，或舊 Strata 只監聽 127.0.0.1，工具會停止並說明原因，不會隨意結束其他程式。

## 它會更改什麼

- 若模型設定檔仍指向 D:\Strata-data，改為已存在的 C:\Strata-Data；缺檔就停止，不重新下載。
- 保留現有 API key；只有未設定時才產生隨機 key。將 Strata 設為 0.0.0.0:8081，並在修改前備份設定檔到 C:\Strata-main\strata-nvfp4-nvfp4.json.oneclick-original.bak。API key 不會印在視窗或記錄中。
- 新增或更新 Windows 防火牆規則 Strata-WSL-Bridge-8081，只允許**目前 WSL 來源 IP → Windows 的 WSL 閘道 IP：TCP 8081**。規則不鎖定 Python 路徑，因為先前實際程序是 C:\Python313\python.exe，而虛擬環境路徑與它不同。
- 只有在兩條先前確認的 Python Public 封鎖規則仍啟用、確實指向正在執行 Strata 的 Python，且 Public 預設入站政策仍為 Block 時，才停用它們。規則 ID 為 {3B3AFB56-6CED-4304-BDCA-FCE5021C313D} 和 {16CF1CAB-93F4-48C0-9A8F-74D274EDB427}。新安裝包不會停用其他未知規則。防火牆本身保持開啟；停用這兩條封鎖規則後，系統其他既有的允許規則仍可能生效，請留意自己以前建立的寬鬆規則。
- 從 WSL 檢查 /health、需要 API key 的 /v1/models，並做一次實際 /v1/chat/completions 提問。成功後，在**執行檢查的 WSL 使用者**家目錄寫入權限 0600 的 ~/strata-wsl.env，內含 API 網址、模型名稱與 key。不要分享此檔。

如果你目前是以 WSL 的 root 帳號執行，設定檔位於 /root/strata-wsl.env。OpenClaw 或 Hermes 若用另一個 WSL 使用者執行，需以該使用者重跑 check-strata.py 來產生其自己的設定檔；不要改成全員可讀權限。

## 在 WSL 用 Python 提問

安裝成功後，在 WSL 終端機執行：

    source ~/strata-wsl.env
    python3 /mnt/d/agent-evolution-platform/strata_wsl_oneclick/ASK.py '請用繁體中文簡短介紹你自己'

ASK.py 使用 Python 標準函式庫呼叫 Strata 的 OpenAI 相容 API，不需要安裝 openai 套件。若改用 OpenAI Python 套件，使用環境變數 OPENAI_BASE_URL、OPENAI_API_KEY 和 STRATA_MODEL 即可。

## 還原與排查

在**系統管理員 PowerShell** 執行下列指令，可刪除本工具的 WSL 允許規則，並重新啟用**本工具此次停用**的 Python 封鎖規則：

    powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'D:\agent-evolution-platform\strata_wsl_oneclick\FIREWALL.ps1' -Mode restore

若你在使用本工具之前已手動停用那兩條封鎖規則，還原程式不會擅自改變它們。還原也不會刪除模型或停止 Strata。設定檔原始備份保留在 Strata 程式資料夾；若需要還原設定，請先停止 Strata，檢查備份內容後再手動處理。

若安裝失敗，請貼上視窗中 FAILED 後的錯誤訊息。若是 Strata 啟動問題，也可查看 ZIP 資料夾中的 strata-server.out.log 和 strata-server.err.log；貼出前請先確認沒有個人資訊。
