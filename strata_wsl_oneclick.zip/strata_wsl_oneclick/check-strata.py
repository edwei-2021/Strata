#!/usr/bin/env python3
"""Check Windows Strata from WSL2 and write local client settings after success."""

import argparse
import ipaddress
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import tempfile
import urllib.error
import urllib.request


def gateway() -> str:
    if "microsoft" not in Path("/proc/sys/kernel/osrelease").read_text().lower():
        raise ValueError("Automatic gateway detection requires WSL2; supply --host if testing elsewhere")
    routes = json.loads(subprocess.check_output(["ip", "-j", "-4", "route", "show", "default"], text=True))
    for route in routes:
        if route.get("gateway"):
            return str(ipaddress.IPv4Address(route["gateway"]))
    raise ValueError("No WSL2 IPv4 default gateway; inspect: ip -4 route show default")


def first_key(value) -> str:
    if isinstance(value, list):
        return str(value[0]) if value else ""
    if isinstance(value, str):
        return value.split(",", 1)[0].strip()
    return ""


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="/mnt/c/Strata-main/strata-nvfp4-nvfp4.json",
                        help="Windows Strata JSON config as seen from WSL2")
    parser.add_argument("--host", help="Explicit Windows IPv4 address; default: current WSL2 gateway")
    parser.add_argument("--port", type=int, default=8081)
    parser.add_argument("--infer", action="store_true", help="Also send one real chat request")
    parser.add_argument("--timeout", type=float, default=900, help="Inference timeout in seconds")
    parser.add_argument("--env-file", default=str(Path.home() / "strata-wsl.env"))
    args = parser.parse_args()
    if not 1 <= args.port <= 65535 or args.timeout <= 0:
        parser.error("port must be 1..65535 and timeout must be positive")
    cfg = json.loads(Path(args.config).read_text(encoding="utf-8-sig"))
    key = first_key(cfg.get("api_key"))
    if not key:
        raise ValueError("No API key in the Strata config; run Windows configure first")
    host = str(ipaddress.IPv4Address(args.host or gateway()))
    base = f"http://{host}:{args.port}"
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def request(path: str, payload=None):
        body = None if payload is None else json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(base + path, data=body,
                                     headers={"Authorization": "Bearer " + key,
                                              "Content-Type": "application/json"})
        with opener.open(req, timeout=args.timeout if body is not None else 15) as response:
            return json.load(response)

    print("Windows Strata endpoint:", base)
    health = request("/health")
    if health.get("status") != "ok" or not health.get("loaded"):
        raise ValueError("Strata is reachable but not loaded; inspect its Windows window and log")
    print("PASS health; loaded:", health["loaded"])
    models = request("/v1/models")
    entries = models.get("data", []) if isinstance(models, dict) else []
    if not entries or not isinstance(entries[0], dict) or not entries[0].get("id"):
        raise ValueError("/v1/models did not return a model ID")
    model = entries[0]["id"]
    print("PASS authenticated model listing:", model)

    if args.infer:
        answer = request("/v1/chat/completions", {
            "model": model, "stream": False,
            "messages": [{"role": "user", "content": "Reply with one short greeting."}],
            "max_tokens": 64, "reasoning_effort": "none",
        })
        content = answer["choices"][0]["message"].get("content")
        if not isinstance(content, str) or not content.strip():
            raise ValueError("Chat request returned no visible text; inspect the Windows engine log")
        print("PASS inference:", content.strip()[:200])

    target = Path(args.env_file).expanduser()
    target.parent.mkdir(parents=True, exist_ok=True)
    no_proxy = ",".join(dict.fromkeys(
        [x.strip() for x in os.environ.get("NO_PROXY", "").split(",") if x.strip()]
        + ["localhost", "127.0.0.1", host]
    ))
    values = {
        "STRATA_BASE_URL": base,
        "STRATA_MODEL": model,
        "STRATA_API_KEY": key,
        "OPENAI_BASE_URL": base + "/v1",
        "OPENAI_API_KEY": key,
        "NO_PROXY": no_proxy,
        "no_proxy": no_proxy,
    }
    content = "# Generated for this WSL2 session; contains a Strata API key.\n"
    content += "".join(f"export {name}={shlex.quote(value)}\n" for name, value in values.items())
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=target.parent, delete=False) as stream:
        temporary = Path(stream.name)
        stream.write(content)
    try:
        temporary.chmod(0o600)
        temporary.replace(target)
    finally:
        temporary.unlink(missing_ok=True)
    print("PASS client settings:", target)
    print("Load with: source", shlex.quote(str(target)))


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, IndexError, TypeError, subprocess.CalledProcessError,
            urllib.error.URLError) as exc:
        print("FAIL:", exc, file=sys.stderr)
        sys.exit(1)
